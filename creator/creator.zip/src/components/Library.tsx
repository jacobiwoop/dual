import { useState, useRef } from 'react';
import { Upload, Film, Image as ImageIcon, FolderOpen, Plus, Trash2 } from 'lucide-react';
import { LIBRARY_ITEMS, LIBRARY_FOLDERS } from '@/data/mockData';
import { cn } from '@/lib/utils';
import { useDropzone } from 'react-dropzone';

type LibTab = 'all' | 'folders';

export function Library() {
  const [tab, setTab] = useState<LibTab>('all');
  const [selectedFolderId, setSelectedFolderId] = useState<string | null>(null);
  const uploadRef = useRef<HTMLInputElement>(null);

  const selectedFolder = LIBRARY_FOLDERS.find(f => f.id === selectedFolderId);
  const mediaToShow = selectedFolder
    ? LIBRARY_ITEMS.filter(m => m.folderId === selectedFolder.id)
    : LIBRARY_ITEMS;

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: { 'image/*': [], 'video/*': [] },
    onDrop: (files) => console.log('Uploaded:', files),
  });

  return (
    <div className="p-6 max-w-4xl mx-auto pb-24">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Bibliothèque</h1>
          <p className="text-sm text-gray-500 mt-1">Médias disponibles pour vos messages</p>
        </div>
        <button
          onClick={() => uploadRef.current?.click()}
          className="flex items-center gap-2 px-5 py-2.5 bg-gray-900 text-white rounded-xl text-sm font-semibold hover:bg-gray-800 transition-colors shadow-lg shadow-gray-900/20"
        >
          <Plus size={16} /> Ajouter
        </button>
        <input ref={uploadRef} type="file" accept="image/*,video/*" multiple className="hidden" />
      </div>

      {/* Onglets */}
      <div className="flex gap-2 mb-6">
        {[
          { id: 'all' as LibTab, label: 'Médias', icon: ImageIcon },
          { id: 'folders' as LibTab, label: 'Galerie', icon: FolderOpen },
        ].map(t => (
          <button
            key={t.id}
            onClick={() => { setTab(t.id); setSelectedFolderId(null); }}
            className={cn(
              'flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all',
              tab === t.id ? 'bg-gray-900 text-white shadow-md' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
            )}
          >
            <t.icon size={15} />
            {t.label}
          </button>
        ))}
      </div>

      {/* Breadcrumb dossier */}
      {selectedFolder && (
        <div className="flex items-center gap-2 mb-4">
          <button onClick={() => setSelectedFolderId(null)} className="text-sm text-purple-600 hover:underline font-medium">
            Galerie
          </button>
          <span className="text-gray-400">/</span>
          <span className="text-sm font-bold text-gray-900">{selectedFolder.title}</span>
        </div>
      )}

      {/* Dropzone */}
      <div
        {...getRootProps()}
        className={cn(
          'border-2 border-dashed rounded-2xl p-6 mb-6 text-center transition-all cursor-pointer',
          isDragActive ? 'border-purple-400 bg-purple-50' : 'border-gray-200 hover:border-gray-300 bg-gray-50/50'
        )}
      >
        <input {...getInputProps()} />
        <Upload size={24} className={cn('mx-auto mb-2', isDragActive ? 'text-purple-500' : 'text-gray-400')} />
        <p className="text-sm text-gray-500">
          {isDragActive ? 'Dépose ici !' : 'Glisse des photos/vidéos ou clique pour importer'}
        </p>
      </div>

      {/* --- Onglet MÉDIAS --- */}
      {(tab === 'all' || selectedFolder) && (
        <>
          <p className="text-xs text-gray-400 font-semibold uppercase tracking-wide mb-3">
            {mediaToShow.length} fichier{mediaToShow.length > 1 ? 's' : ''}
          </p>
          {mediaToShow.length === 0 ? (
            <div className="text-center py-16 text-gray-400">
              <ImageIcon size={32} className="mx-auto mb-2 opacity-40" />
              <p className="text-sm">Aucun média dans ce dossier</p>
            </div>
          ) : (
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
              {mediaToShow.map((item) => (
                <div key={item.id} className="relative aspect-square rounded-xl overflow-hidden group border border-gray-100 hover:border-gray-300 transition-all">
                  <img src={item.url} alt="" className="w-full h-full object-cover" />

                  {/* Overlay */}
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-end justify-end p-2 opacity-0 group-hover:opacity-100">
                    <button className="p-1.5 bg-red-500/90 text-white rounded-lg hover:bg-red-600 transition-colors">
                      <Trash2 size={12} />
                    </button>
                  </div>

                  {item.type === 'video' && (
                    <div className="absolute top-1.5 left-1.5 bg-black/60 rounded-md p-1">
                      <Film size={10} className="text-white" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* --- Onglet GALERIE : liste des dossiers --- */}
      {tab === 'folders' && !selectedFolder && (
        <>
          <p className="text-xs text-gray-400 font-semibold uppercase tracking-wide mb-3">
            {LIBRARY_FOLDERS.length} dossier{LIBRARY_FOLDERS.length > 1 ? 's' : ''}
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {LIBRARY_FOLDERS.map(folder => (
              <button
                key={folder.id}
                onClick={() => setSelectedFolderId(folder.id)}
                className="relative rounded-2xl overflow-hidden aspect-[4/3] group border border-gray-100 hover:border-purple-300 transition-all shadow-sm hover:shadow-md"
              >
                <img src={folder.coverUrl} alt={folder.title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-3 text-left">
                  <p className="font-bold text-white text-sm truncate">{folder.title}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <p className="text-white/70 text-xs">
                      {LIBRARY_ITEMS.filter(m => m.folderId === folder.id).length} médias
                    </p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
