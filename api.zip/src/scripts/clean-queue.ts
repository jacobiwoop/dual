import { mediaQueue } from '../lib/queue';
import logger from '../lib/logger';

async function cleanQueue() {
  try {
    logger.info('🧹 Cleaning media queue...');
    
    // Supprimer tous les jobs
    await mediaQueue.obliterate({ force: true });
    
    logger.info('✅ Queue cleaned');
    
    await mediaQueue.close();
    process.exit(0);
  } catch (error: any) {
    logger.error({ error }, '❌ Failed to clean queue');
    process.exit(1);
  }
}

cleanQueue();
